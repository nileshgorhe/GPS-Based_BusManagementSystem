package com.health.conductortrackapp;

public class Urls {

   // public static final String BASE_URL_2 = "http://192.168.43.57/brbun_web_services/";

 //public static final String BASE_URL = "http://192.168.43.57/busTrackingSystem/";

 public static final String BASE_URL = "https://bustracksystemdemo.000webhostapp.com/busTrackingSystem/";

 public static final String URL_GET_CONDUCTOR_LIST = BASE_URL + "conductorList.php";
 public static final String URL_GET_LAT_LONG = BASE_URL + "getLatLong.php";

}
