package com.health.conductortrackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class BuyPassActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String selectedRoute, selectedPlan;
    EditText passangerName, passangerAddress, passangerContactNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_pass);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        Spinner spinnerValidity = (Spinner) findViewById(R.id.validitySpinner);
        passangerName = findViewById(R.id.et_passanger_name);
        passangerAddress = findViewById(R.id.et_address);
        passangerContactNumber = findViewById(R.id.et_contact_number);

        spinner.setOnItemSelectedListener(this);
        // spinnerValidity.setOnItemSelectedListener(this);

        List<String> routeList = new ArrayList<String>();
        routeList.add("Nashik To pune (120 Rs Per Day)");
        routeList.add("Pune to Mumbai (80 Rs per Day)");
        routeList.add("Nashik to Mumbai (160 Rs per Day)");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, routeList);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);


        List<String> validityList = new ArrayList<String>();
        validityList.add("1 Month");
        validityList.add("3 Month");
        validityList.add("6 Month");
        ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, validityList);

        // Drop down layout style - list view with radio button
        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinnerValidity.setAdapter(dataAdapter1);


        spinnerValidity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                selectedPlan = adapterView.getItemAtPosition(i).toString();
                // Showing selected spinner item
               // Toast.makeText(adapterView.getContext(), "Selected: " + selectedPlan, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        selectedRoute = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
       // Toast.makeText(parent.getContext(), "Selected: " + selectedRoute, Toast.LENGTH_LONG).show();
    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    public void proceed(View view) {
        if (isEmpty(passangerName)) {
            passangerName.setError("Passanger Name Required");
        }
        else if (isEmpty(passangerAddress))
        {
            passangerAddress.setError("Passanger Address Required");
        }
        else if (isEmpty(passangerContactNumber))
        {
            passangerContactNumber.setError("Passanger contact Required");
        }
        else
        {
            Intent intent = new Intent(BuyPassActivity.this,PreeviewActivity.class);
            intent.putExtra("passangerName",passangerName.getText().toString());
            intent.putExtra("passangerAddress",passangerAddress.getText().toString());
            intent.putExtra("passangerContact",passangerContactNumber.getText().toString());
            intent.putExtra("passangerRoute",selectedRoute);
            intent.putExtra("passangerPlan",selectedPlan);
            startActivity(intent);
        }


    }


    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
}