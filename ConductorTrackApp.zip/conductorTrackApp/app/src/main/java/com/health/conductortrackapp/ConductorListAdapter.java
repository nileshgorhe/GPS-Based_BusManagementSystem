package com.health.conductortrackapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;

public class ConductorListAdapter extends RecyclerView.Adapter<ConductorListAdapter.ViewHolder> {

    Context context;
    ArrayList<HashMap<String, String>> conductorList;

    public ConductorListAdapter(Context context, ArrayList<HashMap<String, String>> conductorList) {
        this.context = context;
        this.conductorList = conductorList;

    }


    @NonNull
    @Override
    public ConductorListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.conductor_list_item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ConductorListAdapter.ViewHolder holder, int position) {

        HashMap<String, String> hm = conductorList.get(position);

        holder.txtConductorName.setText("" + hm.get("name"));
        holder.txtConductorContactNumber.setText("" + hm.get("contactNumber"));
        holder.txtConductorVehicleNumber.setText("" + hm.get("vehicleNumber"));

        holder.conductorCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MainActivity.class);
                intent.putExtra("contactNumber", hm.get("contactNumber"));
                context.startActivity(intent);


            }
        });

    }

    @Override
    public int getItemCount() {
        return conductorList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtConductorName, txtConductorContactNumber, txtConductorVehicleNumber;
        CardView conductorCard;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtConductorName = itemView.findViewById(R.id.txt_conductor_name);
            txtConductorContactNumber = itemView.findViewById(R.id.txt_conductor_mobile_number);
            txtConductorVehicleNumber = itemView.findViewById(R.id.txt_conductor_vehicle_number);
            conductorCard = itemView.findViewById(R.id.conductor_card);

        }
    }

}
