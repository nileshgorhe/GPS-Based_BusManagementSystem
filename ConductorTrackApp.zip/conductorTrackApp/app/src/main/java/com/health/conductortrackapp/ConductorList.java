package com.health.conductortrackapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.victor.loading.rotate.RotateLoading;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ConductorList extends AppCompatActivity {

    private RecyclerView rvConductor;
    ArrayList<HashMap<String, String>> conductorList;
    ConductorListAdapter conductorListAdapter;
    private RotateLoading rotateLoading;
    private SwipeRefreshLayout swipeContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conductor_list);

      /*  if (android.os.Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(getResources().getColor(R.color.status_bar));
        }*/

        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView txtRestTittle = findViewById(R.id.txt_rest_tittle);

        TextView txtBuyNow = findViewById(R.id.txt_buy_pass);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(false);
        conductorList = new ArrayList<>();
        rvConductor = findViewById(R.id.rv_conductor);
        rotateLoading = (RotateLoading) findViewById(R.id.rotateloading);
        swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true);
        rvConductor.setLayoutManager(layoutManager);
        rvConductor.setHasFixedSize(true);

        getConductorList();

        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        conductorList.clear();
                        getConductorList();
                        // Stop animation (This will be after 3 seconds)
                        swipeContainer.setRefreshing(false);
                    }
                }, 2000); // Delay in millis

            }
        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);



        txtBuyNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConductorList.this,BuyPassActivity.class);
                startActivity(intent);
            }
        });

    }


    public void getConductorList() {

        conductorList.clear();

        rotateLoading.start();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Urls.URL_GET_CONDUCTOR_LIST, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("listResponse", "" + response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String code = jsonObject.getString("code");
                    if (code.equals("1")) {

                        rotateLoading.stop();

                        JSONArray jsonArray = jsonObject.getJSONArray("conductorList");

                        // JSONObject object = jsonObject.getJSONObject("conductorList");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            HashMap<String, String> hm = new HashMap<>();
                            JSONObject object = jsonArray.getJSONObject(i);
                            hm.put("name", object.getString("name"));
                            hm.put("contactNumber", object.getString("contactNumber"));
                            hm.put("vehicleNumber", object.getString("vehicleNumber"));
                            hm.put("latitude", object.getString("latitude"));
                            hm.put("longitude", object.getString("longitude"));
                            conductorList.add(hm);


                        }
                        conductorListAdapter = new ConductorListAdapter(ConductorList.this, conductorList);
                        rvConductor.setAdapter(conductorListAdapter);
                        conductorListAdapter.notifyDataSetChanged();


                    } else {
                        rotateLoading.stop();
                        Toast.makeText(ConductorList.this, "No Conductor found..", Toast.LENGTH_SHORT).show();

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    rotateLoading.stop();
                    Log.i("exception", "" + e);
                    Toast.makeText(ConductorList.this, "PLEASE TRY AFTER SOME TIME", Toast.LENGTH_SHORT).show();

                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("error", "" + error);
                rotateLoading.stop();
                Toast.makeText(ConductorList.this, "PLEASE TRY AFTER SOME TIME", Toast.LENGTH_SHORT).show();

            }
        }) {


        };


        RequestQueue requestQueue = Volley.newRequestQueue(ConductorList.this);
        requestQueue.add(stringRequest);

    }


}