package com.health.conductortrackapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class PreeviewActivity extends AppCompatActivity {

    String passengerName, passangerAddress, passangerContact, selectedRoute, selectedPlan, startDate, endDate, passNumber, selectedRouteAfterCut, source, destination;
    int planValue, singlePassvalue, totalAmount, monthDays;
    TextView txtPassnumber, txtCurrentDate, txtPassengerName, txtPassengerAddress, txtPassengerContactNumber, txtPassValidity, txtValidFrom, txtValidTo,
            txtSource, txtDestination, txtSingleDayAmount, txtNumberOfDays, txtTotalAmount;

    Button btnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preeview);



      /*  Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(false);*/


        Intent intent = getIntent();

        passengerName = intent.getStringExtra("passangerName");
        passangerAddress = intent.getStringExtra("passangerAddress");
        passangerContact = intent.getStringExtra("passangerContact");
        selectedPlan = intent.getStringExtra("passangerPlan");
        selectedRoute = intent.getStringExtra("passangerRoute");

        startDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        final int random = new Random().nextInt(61) + 20;
        passNumber = "PASSRS" + random;

        Log.i("passNumber", "" + passNumber);
        Log.i("startDate", "" + startDate);

        txtPassnumber = findViewById(R.id.txtPassNumber);
        txtCurrentDate = findViewById(R.id.txtCurrentDate);
        txtPassengerName = findViewById(R.id.txtPassengerName);
        txtPassengerAddress = findViewById(R.id.txtPassengerAddress);
        txtPassengerContactNumber = findViewById(R.id.txtPassengerContact);
        btnSubmit = findViewById(R.id.btnSubmit);


        txtPassValidity = findViewById(R.id.txtPassValidity);
        txtValidFrom = findViewById(R.id.txtValidFrom);
        txtValidTo = findViewById(R.id.txtValidTo);
        txtSource = findViewById(R.id.txtSource);
        txtDestination = findViewById(R.id.txtDestination);

        txtSingleDayAmount = findViewById(R.id.txtSingleDayAmount);
        txtNumberOfDays = findViewById(R.id.txtNumberOfDays);
        txtTotalAmount = findViewById(R.id.txtTotalPaybleAmount);


        if (selectedPlan.equals("1 Month")) {
            monthDays = 30;
            Date date = null;
            Calendar cal = Calendar.getInstance(); //Get the Calendar instance
            cal.add(Calendar.MONTH, 1);//Three months from now
            date = cal.getTime();
            endDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
            planValue = 1;
        } else if (selectedPlan.equals("3 Month")) {

            monthDays = 91;
            Date date = null;
            Calendar cal = Calendar.getInstance(); //Get the Calendar instance
            cal.add(Calendar.MONTH, 3);//Three months from now
            date = cal.getTime();
            endDate = new SimpleDateFormat("MM-dd-yyyy").format(date);
            planValue = 3;
        } else {
            monthDays = 183;
            Date date = null;
            Calendar cal = Calendar.getInstance(); //Get the Calendar instance
            cal.add(Calendar.MONTH, 6);//Three months from now
            date = cal.getTime();
            endDate = new SimpleDateFormat("MM-dd-yyyy").format(date);
            planValue = 6;
        }

        Log.i("endDate", "" + endDate);

        if (selectedRoute.equals("Nashik To pune (120 Rs Per Day)")) {

            selectedRouteAfterCut = "Nashik To pune";

            source = "Nashik";
            destination = "Pune";
            singlePassvalue = 120;
        } else if (selectedRoute.equals("Pune to Mumbai (80 Rs per Day)")) {
            selectedRouteAfterCut = "Pune to Mumbai";
            source = "Pune";
            destination = "Mumbai";
            singlePassvalue = 80;
        } else {
            selectedRouteAfterCut = "Nashik to Mumbai";

            source = "Nashik";
            destination = "Mumbai";
            singlePassvalue = 160;
        }

        totalAmount = singlePassvalue * monthDays;


        txtPassnumber.setText("Pass Number:- " + passNumber);
        txtCurrentDate.setText("Date:- " + startDate);
        txtPassengerName.setText("" + passengerName);
        txtPassengerAddress.setText("" + passangerAddress);
        txtPassengerContactNumber.setText("" + passangerContact);
        txtPassValidity.setText("" + selectedPlan);
        txtValidFrom.setText("" + startDate);
        txtValidTo.setText("" + endDate);
        txtSource.setText("" + source);
        txtDestination.setText("" + destination);

        txtSingleDayAmount.setText("Rs. " + singlePassvalue);
        txtNumberOfDays.setText("" + monthDays + " (Days)");
        txtTotalAmount.setText("Rs. " + totalAmount);


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


               // takeScreenshot();

                createPdf(txtPassengerName.getText().toString());

                //  screenShot(view);
            }
        });


    }


    private void takeScreenshot() {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            String mPath = Environment.DIRECTORY_PICTURES.toString() + "/" + now + ".jpg";

            // create bitmap screen capture
            View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            File imageFile = new File(mPath);

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            outputStream.close();

            openScreenshot(imageFile);
        } catch (Throwable e) {
            // Several error may come out with file handling or DOM
            e.printStackTrace();
        }
    }


    public Bitmap screenShot(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),
                view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }


    private void openScreenshot(File imageFile) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(imageFile);
        intent.setDataAndType(uri, "image/*");
        startActivity(intent);
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createPdf(String sometext) {
        // create a new document
        PdfDocument document = new PdfDocument();
        // crate a page description
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        // start a page
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        canvas.drawCircle(50, 50, 30, paint);
        paint.setColor(Color.BLACK);
        canvas.drawText(sometext, 80, 50, paint);
        //canvas.drawt
        // finish the page
        document.finishPage(page);
// draw text on the graphics object of the page
        // Create Page 2
        pageInfo = new PdfDocument.PageInfo.Builder(300, 600, 2).create();
        page = document.startPage(pageInfo);
        canvas = page.getCanvas();
        paint = new Paint();
        paint.setColor(Color.BLUE);
        canvas.drawCircle(100, 100, 100, paint);
        document.finishPage(page);
        // write the document content
        String directory_path = Environment.getExternalStorageDirectory().getPath() + "/mypdf/";
        File file = new File(directory_path);
        if (!file.exists()) {
            file.mkdirs();
        }
        String targetPdf = directory_path + "test-2.pdf";
        File filePath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));
            Toast.makeText(this, "Done", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e("main", "error " + e.toString());
            Toast.makeText(this, "Something wrong: " + e.toString(), Toast.LENGTH_LONG).show();
        }
        // close the document
        document.close();
    }
}