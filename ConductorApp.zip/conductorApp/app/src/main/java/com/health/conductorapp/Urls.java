package com.health.conductorapp;

public class Urls {

    // public static final String BASE_URL_2 = "http://192.168.43.57/brbun_web_services/";

// public static final String BASE_URL = "http://192.168.43.57/busTrackingSystem/";

    public static final String BASE_URL = "https://bustracksystemdemo.000webhostapp.com/busTrackingSystem/";

    public static final String UPDATE_LAT_LONG = BASE_URL + "saveCurrentLocation.php";
    public static final String CONDUCTOR_LOGIN = BASE_URL + "conductorLogin.php";

}
